var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db){

   if (err) throw err;
   var dbo = db.db("music");
   var dsong = {Song_Name:"ThaniyeThananthaniye"};

   dbo.Collection("songdetails").deleteOne(dsong, function(err, opj){
  
      if (err) throw err;  
      console.log("--- ThaniyeThananthaniye song delete ---");
      db.close();
      
  });
});