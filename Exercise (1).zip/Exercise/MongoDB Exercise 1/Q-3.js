
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db){

  if (err) throw err;

  var dbo = db.db("music");

  var songd = [
    {Song_Name:"ThaniyeThananthaniye",Film:"Rhythm",Music_Director:"A.R.Rahman",Singer:"Shankar mahadevan"},
    {Song_Name:"Evano Oruvan",Film:"Alai Payuthey",Music_Director:"A.R.Rahman",Singer:"Swarnalatha"},
    {Song_Name:"Roja Poonthottam",Film:"Kannukkul Nilavu",Music_Director:"Ilaiyaraaja",Singer:["Unnikrishnan","Anuradha Sriram"]},
    {Song_Name:"Vennilavae Vennilavae Vinnaithaandi",Film:"Minsara Kanavu",Music_Director:"A.R.Rahman",Singer:"Hariharan Sadhana Sargam"},
    {Song_Name:"Sollamal Thottu Chellum Thendral",Film:"Dheena",Music_Director:"Yuvan Shankar Raja",Singer:"Hariharan"}
 ]; 

  dbo.Collection("songdetails").insertMany(songd, function(err, res){
  if (err) throw err;  
  console.log("--- song details created ---");
  db.close();
  });
});  