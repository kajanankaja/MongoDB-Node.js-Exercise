
var url = "mongodb://localhost:27017/music";
var MongoClient = require('mongodb').MongoClient;
 

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    
    console.log("Switched to "+db.databaseName+" database");
 
    var doc = {Song_Name:"Ninaipathellam Nadanthuvittal",Film:"Nenjil Or Aalayam",Music_Director:"M.S.Viswanathan Ramamoorthy",Singer:"P.B.Sreenivos"};
    
    
    db.collection("songdetails").insertOne(doc, function(err, res) {
        if (err) throw err;
        console.log("Document inserted");
 
        db.close();
    });
});