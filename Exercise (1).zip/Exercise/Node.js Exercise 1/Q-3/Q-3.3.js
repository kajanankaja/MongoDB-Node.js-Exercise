var fs = require('fs');

fs.appendFile('ukinode.txt', 'It is aimed to provide the necessary training to enter Computer Software industry or to start an IT startup.', function(err) {
    if (err) throw err;
    console.log('another paragraph added!');
   
   });