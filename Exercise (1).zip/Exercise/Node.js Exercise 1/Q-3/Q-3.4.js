var fs = require('fs');

fs.rename('ukinode.txt', 'ukinodejsexercise1.txt', function(err, file) {

 console.log('ukinode name changed!');

});