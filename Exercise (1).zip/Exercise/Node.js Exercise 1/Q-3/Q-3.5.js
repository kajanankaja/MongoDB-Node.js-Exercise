var fs = require('fs');

fs.unlink( 'ukinodejsexercise1.txt', function(err) {

 console.log('ukinodejsexercise1 file removed!');

});