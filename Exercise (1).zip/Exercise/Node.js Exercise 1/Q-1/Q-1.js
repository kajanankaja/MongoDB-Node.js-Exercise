var http = require('http');
var sa = require('./sumaverage.js');

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(`Sum Number =  ${sa.sumNumber(123, 321)}` );
    res.write(`Average Number = ${sa.average(123, 321)}` );
    res.end();
}).listen(1213);