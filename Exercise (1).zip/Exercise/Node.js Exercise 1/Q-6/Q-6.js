var action = require('events');
var emitter = new action.EventEmitter();


var dogsound = function () {
  console.log('I bark when I see strangers !');
}


emitter.on('bark', dogsound);

emitter.emit('bark');