var http = require('http');
var fs = require('fs');

http.createServer(function(req, res) {

  res.writeHead(200, {'Content-Type': 'text/html'});

  if (req.url == '/head.html')
  {


        fs.readFile('head.html', function(err, data){
         
            res.write(data);
            res.end();
              });
  } 
  else
   {
   

        fs.readFile('tail.html', function(err, data){
           
            res.write(data);
            res.end();
              });
    }
}).listen(9090);



